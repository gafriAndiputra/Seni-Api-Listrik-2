require 'webrick'

port = (ARGV[0] || 8088).to_i
root = File.expand_path(File.dirname(__FILE__))

server = WEBrick::HTTPServer.new(
  Port: port,
  DocumentRoot: root,
  AccessLog: [],
)

trap('INT') { server.shutdown }

puts "===================================================="
puts "  Seni Api Listrik Bekasi (CV. Power Global)"
puts "  Server running at: http://localhost:#{port}/"
puts "  Document Root: #{root}"
puts "===================================================="

server.start
