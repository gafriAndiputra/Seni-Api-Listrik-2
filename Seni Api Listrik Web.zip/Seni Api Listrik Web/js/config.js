/**
 * Centralized Configuration for Seni Api Listrik Bekasi (CV. Power Global)
 * Modern Industrial Workshop Web Application
 * Source of truth for business metadata, service catalog, portfolio gallery,
 * pricing estimation metrics, and dynamic WhatsApp URL generators.
 */

const SITE_CONFIG = {
  business: {
    brandName: "Seni Api Listrik Bekasi",
    legalName: "CV. Power Global",
    tagline: "Spesialis Fabrikasi Besi, Bengkel Las & Instalasi Listrik Andal",
    phoneDisplay: "0813-9818-1885",
    phoneRaw: "081398181885",
    phoneInternational: "6281398181885",
    email: "kontak@seniapilistrik.com",
    address: {
      street: "Kawasan Perumahan Puri Cendana",
      subdistrict: "Tambun Selatan",
      city: "Bekasi",
      province: "Jawa Barat",
      postalCode: "17510",
      country: "Indonesia",
      full: "Puri Cendana, Tambun Selatan, Kabupaten Bekasi, Jawa Barat 17510",
      geo: {
        latitude: -6.2624,
        longitude: 107.0583
      }
    },
    operatingHours: "Senin – Sabtu: 08:00 – 18:00 WIB (Konsultasi WhatsApp 24 Jam)",
    logoUrl: "assets/images/logo.png",
    faviconUrl: "assets/images/favicon.png",
    metaTitle: "Seni Api Listrik Bekasi | Bengkel Las, Fabrikasi & Instalasi Listrik (CV. Power Global)",
    metaDescription: "Bengkel las dan jasa fabrikasi terbaik di Bekasi oleh CV. Power Global. Melayani kanopi alderon, pagar woodplank & laser cutting, teralis, rolling door, neon box, dan instalasi panel listrik. Konsultasi & survei cepat via WhatsApp 0813-9818-1885."
  },

  serviceAreas: [
    { name: "Tambun Selatan", note: "Puri Cendana, Mangunjaya, Graha Puri, Sumberjaya (Respon Cepat)" },
    { name: "Tambun Utara & Cibitung", note: "Wanajaya, Telaga Asih, Kawasan Industri MM2100" },
    { name: "Cikarang", note: "Cikarang Barat, Cikarang Utara, Jababeka, Lippo Cikarang" },
    { name: "Bekasi Timur", note: "Duren Jaya, Aren Jaya, Margahayu, Bulak Kapal" },
    { name: "Bekasi Barat", note: "Kranji, Kota Baru, Bintara, Jakasampurna" },
    { name: "Bekasi Selatan", note: "Pekayon, Grand Galaxy City, Jaka Setia" },
    { name: "Bekasi Utara", note: "Harapan Baru, Summarecon Bekasi, Teluk Pucung" },
    { name: "Mustika Jaya & Rawalumbu", note: "Grand Wisata, Dukuh Zamrud, Pengasinan, Bojong Menteng" },
    { name: "Babelan & Tarumajaya", note: "Harapan Indah, Babelan Kota, Kebalen" }
  ],

  services: [
    {
      id: "pagar-pintu",
      category: "pagar",
      name: "Pintu & Pagar Besi",
      shortDesc: "Pagar minimalis hollow, kombinasi woodplank GRC, cutting laser plat motif, dan besi tempa klasik.",
      fullDesc: "Fabrikasi pagar dorong, pagar lipat, dan pintu gerbang kokoh dengan perlindungan anti-karat prima. Pilihan motif minimalis modern, serat kayu woodplank alami, cutting laser floral/geometris, hingga pagar tempa mewah.",
      specs: ["Besi Hollow Galvanis 40x40 & 40x60 (1.2mm - 1.6mm)", "Plat Cutting Laser CNC Presisi", "Papan Woodplank GRC Tahan Cuaca", "Finishing Epoxy Primer + Topcoat Anti-Karat"],
      startingPrice: "Mulai Rp 450.000 / m²",
      ctaLabel: "Konsultasi Model Pagar",
      icon: "gate"
    },
    {
      id: "kanopi-atap",
      category: "kanopi",
      name: "Kanopi & Rangka Baja",
      shortDesc: "Kanopi carport alderon twinwall, spandek galvalum berpasir, dan solarflat transparan elegan.",
      fullDesc: "Konstruksi atap kanopi kokoh peredam panas dan suara hujan. Pilihan material atap uPVC Alderon berongga, atap spandek galvalum ekonomis, atap solarflat mewah jernih, dengan rangka hollow galvanis dobel atau tiang baja WF.",
      specs: ["Atap Alderon Double Layer uPVC", "Spandek Pasir Galvalum Anti-Bising", "Solarflat Polycarbonate Solid", "Rangka Hollow Besi 40x60 / 40x80 SNI"],
      startingPrice: "Mulai Rp 380.000 / m²",
      ctaLabel: "Konsultasi Kanopi",
      icon: "canopy"
    },
    {
      id: "teralis-jendela",
      category: "teralis",
      name: "Teralis & Pintu Pengaman",
      shortDesc: "Teralis jendela minimalis pengaman anti-maling dan pintu kawat nyamuk baja.",
      fullDesc: "Perlindungan maksimal untuk hunian dan ruko dengan estetika modern. Menjaga ventilasi udara tetap segar sekaligus mengamankan akses jendela dan pintu masuk dari risiko kejahatan.",
      specs: ["Besi Kotak Nako 10mm - 12mm / Hollow", "Pintu Kawat Nyamuk Baja Baja Tahan Gunting", "Kunci Pengaman Tambahan (Deadbolt)", "Pilihan Cat Doff Hitam, Putih, atau Tempa"],
      startingPrice: "Mulai Rp 200.000 / unit",
      ctaLabel: "Konsultasi Teralis",
      icon: "grille"
    },
    {
      id: "railing-balkon",
      category: "railing",
      name: "Railing Tangga & Balkon",
      shortDesc: "Railing tangga modern hollow, stainless steel 304, kaca tempered, dan lantai mezzanine.",
      fullDesc: "Konstruksi pengaman tangga dan balkon lantai dua yang estetis, kokoh, dan berstandar keselamatan tinggi. Desain garis minimalis industrial, kombinasi pegangan kayu solid, atau stainless steel tahan karat seumur hidup.",
      specs: ["Besi Hollow Galvanis / Pipa Besi", "Stainless Steel Grade 304 Mirror / Hairline", "Kaca Tempered 8mm - 10mm Safety", "Handrail Kayu Kamper / Besi Kotak"],
      startingPrice: "Mulai Rp 450.000 / m'",
      ctaLabel: "Konsultasi Railing",
      icon: "railing"
    },
    {
      id: "rolling-door",
      category: "rolling-door",
      name: "Rolling Door & Folding Gate",
      shortDesc: "Pintu gulung one sheet toko, folding gate harmonika ruko, dan pintu lift barang.",
      fullDesc: "Solusi pintu keamanan komersial untuk toko, ruko pasar, kios, gudang, maupun pintu kandang lift barang. Sistem roda rel halus, plat daun kokoh, serta penguncian silinder kuat.",
      specs: ["Rolling Door Besi / Aluminium / Galvalum", "Folding Gate Harmonika Plat Tebal", "Sistem Rel Tanam Presisi", "Pintu Harmonika Khusus Lift Barang Industri"],
      startingPrice: "Mulai Rp 450.000 / m²",
      ctaLabel: "Konsultasi Rolling Door",
      icon: "roller"
    },
    {
      id: "baja-ringan",
      category: "baja-ringan",
      name: "Rangka Baja Ringan",
      shortDesc: "Pemasangan rangka atap canal C75 galvalum, reng, dan genteng metal / spandek.",
      fullDesc: "Pemasangan rangka atap rumah baru dan renovasi penggantian kayu lapuk dengan konstruksi baja ringan tahan rayap dan tahan karat. Perhitungan kuda-kuda presisi menjamin keamanan atap.",
      specs: ["Canal C75 Tebal 0.75mm Standar SNI", "Reng Galvalum Simetris", "Genteng Metal Berpasir / Spandek", "Bongkar Pasang Atap Lama Rapi"],
      startingPrice: "Mulai Rp 160.000 / m²",
      ctaLabel: "Konsultasi Baja Ringan",
      icon: "steel"
    },
    {
      id: "neon-box",
      category: "neon-box",
      name: "Neon Box & Signage Reklame",
      shortDesc: "Neon box akrilik custom LED backlit, huruf timbul galvanis/stainless untuk toko & resto.",
      fullDesc: "Tingkatkan daya tarik bisnis dan ruko Anda agar terlihat terang benderang siang dan malam. Menggunakan akrilik bermutu tinggi, visual printing tajam, modul LED hemat listrik, dan rangka besi galvanis anti-karat.",
      specs: ["Akrilik Milky Tebal 3mm Presisi", "Modul LED Samsung / Epistar Tahan Air (IP65)", "Visual Sticker Backlit Oracal / UV Print", "Rangka Hollow Galvanis & Lis Aluminium"],
      startingPrice: "Mulai Rp 1.100.000 / unit",
      ctaLabel: "Konsultasi Neon Box",
      icon: "neonbox"
    },
    {
      id: "instalasi-listrik",
      category: "listrik",
      name: "Instalasi Listrik & Panel Distribusi",
      shortDesc: "Perakitan box panel KWh/MDP, instalasi titik lampu/stop kontak rumah & ruko berstandar SNI.",
      fullDesc: "Layanan teknik kelistrikan profesional untuk hunian, ruko bisnis, gudang, dan industri ringan. Melayani perakitan box panel listrik distribusi (MDP/SDP), penataan kabel rapi (rewiring), pembagian beban daya MCB, hingga grounding pengaman petir.",
      specs: ["Kabel Tembaga Standar SNI (Supreme / Eterna)", "Komponen MCB/MCCB Schneider / ABB / Chint", "Box Panel Powder Coating Tahan Panas & Karat", "Uji Beban, Grounding & Safety Check"],
      startingPrice: "Mulai Rp 95.000 / titik",
      ctaLabel: "Konsultasi Listrik & Panel",
      icon: "electric"
    },
    {
      id: "cctv-keamanan",
      category: "listrik",
      name: "Pemasangan CCTV & Security System",
      shortDesc: "Paket CCTV IP/Analog HD, setting online ke smartphone, dan instalasi kabel rapi.",
      fullDesc: "Pantau keamanan rumah tinggal dan tempat usaha secara real-time dari mana saja melalui smartphone. Instalasi kabel tersembunyi rapi, konfigurasi DVR/NVR, serta dukungan teknisi lokal berpengalaman di Bekasi.",
      specs: ["Kamera Indoor & Outdoor Night Vision (Infrared/ColorVu)", "DVR/NVR Harddisk Khusus Surveilans", "Koneksi Aplikasi Online Cloud Smartphone", "Garansi Pemasangan & Setting Lengkap"],
      startingPrice: "Mulai Rp 1.800.000 / paket",
      ctaLabel: "Konsultasi CCTV",
      icon: "cctv"
    }
  ],

  portfolioItems: [
    {
      id: "porto-01",
      category: "pagar",
      title: "Pagar Laser Cutting Motif Floral Elegan",
      location: "Perumahan Bekasi Timur",
      tag: "Pagar Cutting Laser",
      image: "assets/portfolio/pagar-laser-cutting.jpeg",
      desc: "Pagar plat cutting laser CNC motif ornamen floral dengan nomor rumah presisi. Rangka hollow doff hitam mewah & anti-karat."
    },
    {
      id: "porto-02",
      category: "pagar",
      title: "Pagar Lipat Woodplank Kayu Rangka Hitam",
      location: "Puri Cendana, Tambun Selatan",
      tag: "Pagar Woodplank Modern",
      image: "assets/portfolio/pagar-woodplank-hitam.jpeg",
      desc: "Kombinasi besi hollow galvanis hitam doff dan panel woodplank serat kayu tahan cuaca. Sistem lipat hemat ruang."
    },
    {
      id: "porto-03",
      category: "pagar",
      title: "Pagar Dorong Minimalis Woodplank Silver",
      location: "Grand Wisata, Bekasi",
      tag: "Pagar Dorong Modern",
      image: "assets/portfolio/pagar-dorong-silver.jpeg",
      desc: "Pagar dorong modern kombinasi hollow silver dan lisplang kayu alami dengan rel roda bearing lancar anti-selip."
    },
    {
      id: "porto-04",
      category: "pagar",
      title: "Pagar Besi Tempa Klasik Ornamen Emas",
      location: "Mustika Jaya, Bekasi",
      tag: "Pagar Besi Tempa",
      image: "assets/portfolio/pagar-besi-tempa-klasik.jpeg",
      desc: "Pagar besi tempa klasik warna hijau tosca kombinasi ornamen tombak emas tempa mewah. Kokoh dan artistik."
    },
    {
      id: "porto-05",
      category: "pagar",
      title: "Pagar Lipat Modern Putih Elegan",
      location: "Tambun Selatan, Bekasi",
      tag: "Pagar Lipat Minimalis",
      image: "assets/portfolio/pagar-lipat-putih.jpeg",
      desc: "Pintu pagar lipat carport warna putih bersih kombinasi panel woodplank coklat kayu untuk rumah tipe minimalis modern."
    },
    {
      id: "porto-06",
      category: "pagar",
      title: "Pagar Dorong Woodplank Minimalis Rapi",
      location: "Cikarang Barat",
      tag: "Pagar Dorong Woodplank",
      image: "assets/portfolio/pagar-dorong-woodplank.jpeg",
      desc: "Pagar dorong kuat dengan finishing cat polyurethane anti-gores dan panel kayu tahan terik matahari serta hujan."
    },
    {
      id: "porto-07",
      category: "kanopi",
      title: "Konstruksi Rangka Kanopi Baja Hollow Hitam",
      location: "Puri Cendana, Tambun",
      tag: "Rangka Kanopi Carport",
      image: "assets/portfolio/kanopi-rangka-hollow-hitam.jpeg",
      desc: "Pemasangan konstruksi rangka kanopi carport bertingkat dengan tiang kokoh besi hollow tebal dan balok gording presisi."
    },
    {
      id: "porto-08",
      category: "kanopi",
      title: "Fabrikasi Booth & Pos Jaga Spandek",
      location: "Kawasan Industri MM2100",
      tag: "Booth & Rangka Baja",
      image: "assets/portfolio/booth-pos-jaga-spandek.jpeg",
      desc: "Fabrikasi pos keamanan dan booth jaga portabel rangka hollow galvanis berdinding atap spandek kokoh tahan benturan."
    },
    {
      id: "porto-09",
      category: "kanopi",
      title: "Booth Usaha Kontainer Spandek Coklat",
      location: "Tambun Selatan, Bekasi",
      tag: "Booth Usaha Custom",
      image: "assets/portfolio/booth-usaha-container.jpeg",
      desc: "Gerai usaha booth kontainer mini siap pakai dengan jendela bukaan hidrolik dan atap kanopi peneduh."
    },
    {
      id: "porto-10",
      category: "rolling-door",
      title: "Pintu Harmonika Folding Gate Lift Ruko",
      location: "Ruko Sentra Niaga Kalimalang Bekasi",
      tag: "Folding Gate Lift",
      image: "assets/portfolio/folding-gate-lift.jpeg",
      desc: "Pintu harmonika teralis besi safety untuk pengaman lift barang ruko 3 lantai. Pengoperasian halus dan aman."
    },
    {
      id: "porto-11",
      category: "rolling-door",
      title: "Instalasi Folding Gate Lift Interior",
      location: "Gudang Distribusi Cikarang",
      tag: "Pintu Pengaman Lift",
      image: "assets/portfolio/folding-gate-lift-interior.jpeg",
      desc: "Pemasangan pintu harmonika galvanis kokoh berstandar beban industri untuk sangkar lift barang ruko dan pabrik."
    },
    {
      id: "porto-12",
      category: "rolling-door",
      title: "Pintu Aluminium & Rolling Shutter Toko",
      location: "Bekasi Kota",
      tag: "Pintu Toko & Rolling Door",
      image: "assets/portfolio/pintu-aluminium-rolling-door.jpeg",
      desc: "Pemasangan kusen pintu kaca aluminium biru modern dipadu dengan rolling door pelindung keamanan toko."
    },
    {
      id: "porto-13",
      category: "neon-box",
      title: "Neon Box 3D Teras Steak LED Backlit",
      location: "Resto Kuliner Bekasi",
      tag: "Neon Box Kuliner 3D",
      image: "assets/portfolio/neon-box-teras-steak.jpeg",
      desc: "Neon box akrilik custom logo 3D dengan modul lampu LED Samsung hemat daya. Visual menyala tajam dan menarik konsumen."
    },
    {
      id: "porto-14",
      category: "neon-box",
      title: "Neon Box Fasad Toko 'Esencia Parfum'",
      location: "Ruko Puri Cendana, Tambun",
      tag: "Neon Box Toko Ruko",
      image: "assets/portfolio/neon-box-esencia-parfum.jpeg",
      desc: "Neon box plang nama toko akrilik minimalis dipasang di atas fasad ruko dengan pencahayaan putih benderang merata."
    },
    {
      id: "porto-15",
      category: "listrik",
      title: "Deretan Box Panel Distribusi & KWh Listrik",
      location: "Proyek Pabrik & Ruko Bekasi",
      tag: "Perakitan Box Panel",
      image: "assets/portfolio/box-panel-distribusi-listrik.jpeg",
      desc: "Produksi batch box panel listrik industri dengan finishing powder coating anti-karat safety orange dan industrial grey."
    },
    {
      id: "porto-16",
      category: "listrik",
      title: "Panel Kontrol Listrik Powder Coating",
      location: "Kawasan Industri Cibitung",
      tag: "Box Panel Listrik",
      image: "assets/portfolio/panel-listrik-powder-coating.jpeg",
      desc: "Box panel instalasi listrik proteksi cuaca outdoor/indoor dengan plat tebal, engsel kuat, dan seal kedap air."
    },
    {
      id: "porto-17",
      category: "listrik",
      title: "Instalasi Lampu Kap Kisi & Kelistrikan Plafon",
      location: "Kantor & Showroom Bekasi Timur",
      tag: "Instalasi Listrik Komersial",
      image: "assets/portfolio/instalasi-lampu-plafon.jpeg",
      desc: "Pemasangan lampu troffer kap kisi pada plafon akustik gypsum serta instalasi jalur kabel titik stop kontak dan saklar."
    },
    {
      id: "porto-18",
      category: "fabrikasi",
      title: "Pintu Teralis Kawat Nyamuk Baja Minimalis",
      location: "Perumahan Tambun Selatan",
      tag: "Pintu Teralis Pengaman",
      image: "assets/portfolio/pintu-teralis-kawat-nyamuk.jpeg",
      desc: "Pintu teralis besi hollow dengan kawat baja nyamuk rapat, handle silinder kokoh, dan finishing cat duco hitam elegan."
    },
    {
      id: "porto-19",
      category: "fabrikasi",
      title: "Proses Pengelasan Teralis Presisi di Workshop",
      location: "Workshop Seni Api Listrik Bekasi",
      tag: "Proses Las Presisi",
      image: "assets/portfolio/proses-las-teralis.jpeg",
      desc: "Proses perakitan dan pengelasan geometri teralis dengan mesin las inverter berdaya tinggi. Sambungan matang dan rapi."
    },
    {
      id: "porto-20",
      category: "fabrikasi",
      title: "Gerobak Usaha Custom Stainless Steel & Roda",
      location: "Pesanan UMKM Bekasi",
      tag: "Gerobak Usaha Stainless",
      image: "assets/portfolio/gerobak-stainless-aluminium.jpeg",
      desc: "Fabrikasi gerobak jualan keliling bahan stainless steel tahan karat dan higienis, dilengkapi laci kunci dan roda kokoh."
    },
    {
      id: "porto-21",
      category: "fabrikasi",
      title: "Rak Dinding Industrial Besi Hollow & Kayu",
      location: "Cafe & Hunian Modern Bekasi",
      tag: "Rak Industrial Custom",
      image: "assets/portfolio/rak-dinding-industrial.jpeg",
      desc: "Rak dinding gantung tema industrial modern perpaduan rangka hollow besi hitam dan ambalan kayu solid berfurnish alami."
    },
    {
      id: "porto-22",
      category: "fabrikasi",
      title: "Partisi Sekat Ruangan Besi Minimalis Putih",
      location: "Hunian Tambun Bekasi",
      tag: "Partisi Sekat Besi",
      image: "assets/portfolio/partisi-rak-tanaman-putih.jpeg",
      desc: "Partisi ruangan berkonsep rak tanaman hias bertingkat dari hollow besi putih bersih, membagi ruang tamu dengan indah."
    },
    {
      id: "porto-23",
      category: "fabrikasi",
      title: "Rak Display Toko Ruko Bahan Besi Kokoh",
      location: "Supermarket / Toko Retail Bekasi",
      tag: "Rak Display Ruko",
      image: "assets/portfolio/rak-display-toko-ruko.jpeg",
      desc: "Pembuatan deretan rak display bertingkat beban berat untuk penataan barang dagangan toko retail dan ruko komersial."
    },
    {
      id: "porto-24",
      category: "fabrikasi",
      title: "Aktivitas Pengerjaan & Finishing di Bengkel",
      location: "Puri Cendana, Tambun Selatan",
      tag: "Aktivitas Bengkel Las",
      image: "assets/portfolio/bengkel-las-aktivitas.jpeg",
      desc: "Suasana pengerjaan pengelasan railing tangga dan gerobak usaha dengan peralatan kompresor cat spray gun presisi."
    }
  ],

  pricingConfig: {
    categories: [
      {
        id: "kanopi-alderon",
        name: "Kanopi Atap Alderon uPVC (Double Layer)",
        unitType: "area", // m²
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 5,
        defaultWidth: 3,
        basePrice: 580000,
        desc: "Rangka Besi Hollow Galvanis 40x60/40x80 tebal 1.4mm, atap Alderon twinwall kedap panas & suara hujan."
      },
      {
        id: "kanopi-spandek",
        name: "Kanopi Atap Spandek Pasir / Galvalum",
        unitType: "area",
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 4,
        defaultWidth: 3,
        basePrice: 420000,
        desc: "Pilihan ekonomis dan tahan lama. Rangka hollow galvanis anti-karat dengan atap spandek lapis pasir peredam bising."
      },
      {
        id: "kanopi-solarflat",
        name: "Kanopi Solarflat / Polycarbonate Mewah",
        unitType: "area",
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 4,
        defaultWidth: 3,
        basePrice: 650000,
        desc: "Pencahayaan alami mewah sebening kaca tanpa risiko pecah. Rangka hollow minimalis doff elegan."
      },
      {
        id: "pagar-woodplank",
        name: "Pagar Minimalis Kombinasi Woodplank Kayu",
        unitType: "area",
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 4,
        defaultWidth: 1.8,
        basePrice: 650000,
        desc: "Rangka hollow galvanis 40x40/40x60 dengan isian panel woodplank serat kayu tahan cuaca & cat anti-karat."
      },
      {
        id: "pagar-minimalis",
        name: "Pagar Besi Hollow Minimalis Standar",
        unitType: "area",
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 4,
        defaultWidth: 1.5,
        basePrice: 480000,
        desc: "Desain jeruji vertikal/horizontal modern minimalis dengan cat dasar epoxy dan topcoat doff/gloss."
      },
      {
        id: "pagar-laser-cut",
        name: "Pagar Plat Cutting Laser Motif Custom",
        unitType: "area",
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 4,
        defaultWidth: 1.8,
        basePrice: 980000,
        desc: "Plat besi cutting laser motif ornamen floral/batik/geometris modern presisi dengan nomor rumah."
      },
      {
        id: "railing-tangga",
        name: "Railing Tangga & Balkon Minimalis",
        unitType: "length", // meter lari (m')
        unitLabel: "m' (Meter Lari)",
        defaultLength: 6,
        defaultWidth: 1,
        basePrice: 480000,
        desc: "Pegangan tangga aman dan artistik dari hollow galvanis tebal atau stainless steel dengan tiang kokoh."
      },
      {
        id: "teralis-jendela",
        name: "Teralis Jendela Pengaman Minimalis",
        unitType: "count", // unit titik
        unitLabel: "Titik Jendela",
        defaultCount: 4,
        basePrice: 220000,
        desc: "Besi nako 10-12mm atau pipa kotak hollow dengan baut dynabolt tanam dinding anti-congkel."
      },
      {
        id: "rolling-door",
        name: "Rolling Door / Folding Gate Ruko",
        unitType: "area",
        unitLabel: "m² (Meter Persegi)",
        defaultLength: 3,
        defaultWidth: 2.5,
        basePrice: 520000,
        desc: "Pintu gulung galvalum one sheet / harmonika plat tebal dengan sistem kunci silinder kuat."
      },
      {
        id: "instalasi-listrik",
        name: "Instalasi Titik Listrik (Lampu / Stop Kontak)",
        unitType: "count",
        unitLabel: "Titik Kelistrikan",
        defaultCount: 10,
        basePrice: 110000,
        desc: "Jasa penarikan kabel Eterna/Supreme SNI, pipa conduit pelindung kabel, saklar/stop kontak, dan penataan jalur."
      },
      {
        id: "panel-listrik",
        name: "Perakitan Box Panel Distribusi (MDP/SDP)",
        unitType: "count",
        unitLabel: "Unit Box Panel",
        defaultCount: 1,
        basePrice: 1650000,
        desc: "Box panel powder coating, wiring busbar tempa tembaga, grouping MCB Schneider, pilot lamp, dan grounding test."
      }
    ],

    materialGrades: [
      {
        id: "standar",
        name: "Standar SNI (Galvanis 1.2mm / Kabel SNI)",
        multiplier: 1.0,
        note: "Cocok untuk hunian tinggal, hemat dan tahan karat standar."
      },
      {
        id: "premium",
        name: "Premium Heavy Duty (Galvanis 1.4-1.6mm / Epoxy Duco)",
        multiplier: 1.2,
        note: "Pilihan favorit: lebih tebal, sangat kokoh, finishing cat dobel anti-gores."
      },
      {
        id: "industrial",
        name: "Industrial & Stainless Steel (Grade 304 / Baja Tebal)",
        multiplier: 1.5,
        note: "Kekuatan maksimal bebas karat seumur hidup untuk ruko komersial dan pabrik."
      }
    ]
  },

  faq: [
    {
      q: "Apakah Seni Api Listrik Bekasi melayani survei lokasi langsung?",
      a: "Ya! Kami siap datang langsung untuk survei lokasi dan pengukuran akurat di seluruh kawasan Tambun, Cikarang, Cibitung, Bekasi Kota, dan sekitarnya. Cukup hubungi kami melalui WhatsApp untuk menjadwalkan kunjungan."
    },
    {
      q: "Apakah biaya estimasi awal dan konsultasi dikenakan biaya?",
      a: "Konsultasi dan estimasi awal via WhatsApp adalah 100% GRATIS. Anda bebas bertanya mengenai pilihan model, perbandingan material (Alderon vs Spandek, Besi Hollow vs Woodplank), serta estimasi biaya yang sesuai dengan anggaran Anda."
    },
    {
      q: "Material besi dan atap apa saja yang digunakan di bengkel?",
      a: "Kami hanya memakai material berkualitas berstandar SNI: Besi Hollow Galvanis anti-karat (ketebalan 1.2mm s/d 1.6mm), Plat Baja Laser Cutting CNC, Papan Woodplank GRC asli, Atap uPVC Alderon Twinwall, Spandek Galvalum berpasir, Solarflat Polycarbonate, Stainless Steel 304, serta kabel listrik berstandar SNI (Supreme & Eterna)."
    },
    {
      q: "Berapa lama proses fabrikasi hingga pemasangan selesai?",
      a: "Waktu pengerjaan bergantung pada volume dan tingkat kerumitan: Pagar dan kanopi rumah biasanya memakan waktu 4 – 7 hari kerja di bengkel sebelum dipasang rapi di lokasi Anda dalam 1 hari. Kami selalu memberikan estimasi waktu yang transparan dan berkomitmen tepat waktu."
    },
    {
      q: "Apakah pekerjaan pengelasan dan instalasi diberikan garansi?",
      a: "Tentu! Setiap pekerjaan kami disertai garansi pengerjaan dan kerapian. Kami menguji kekuatan sambungan las, kelancaran engsel dan rel roda pagar, serta keamanan jalur kelistrikan sebelum serah terima."
    },
    {
      q: "Bagaimana sistem pembayaran dan alur pemesanannya?",
      a: "Sistem pembayaran transparan dan aman: Konsultasi & kesepakatan desain -> Survei ukuran fix -> Uang muka (DP) untuk pembelian material -> Fabrikasi di bengkel -> Pemasangan & finishing di lokasi -> Pelunasan setelah pekerjaan selesai dan Anda puas dengan hasilnya."
    },
    {
      q: "Apakah melayani pekerjaan di luar kawasan Puri Cendana Tambun?",
      a: "Sangat bisa. Kami melayani seluruh wilayah Kabupaten & Kota Bekasi (Tambun Selatan & Utara, Cikarang, Cibitung, Rawalumbu, Mustika Jaya, Grand Wisata, Bekasi Timur, Barat, Selatan, Utara, Summarecon Bekasi, hingga Harapan Indah)."
    }
  ]
};

/**
 * Helper to build pre-formatted WhatsApp URLs
 */
function getWhatsAppUrl(type = "general", payload = {}) {
  const base = `https://wa.me/${SITE_CONFIG.business.phoneInternational}`;
  let text = "";

  switch (type) {
    case "service":
      text = `Halo Seni Api Listrik Bekasi (CV. Power Global),\n\nSaya ingin berkonsultasi mengenai layanan *${payload.serviceName || "Fabrikasi & Las"}*.\n• Kebutuhan: ${payload.needs || "..."}\n• Rencana Lokasi: ${payload.location || "Bekasi"}\n\nMohon info estimasi biaya dan jadwal survei lokasi. Terima kasih!`;
      break;

    case "portfolio":
      text = `Halo Seni Api Listrik Bekasi,\n\nSaya tertarik dengan hasil pengerjaan di website:\n*${payload.title || "Proyek"}* (${payload.tag || "Portofolio"})\n\nApakah bisa dibuatkan model serupa untuk lokasi saya di *${payload.location || "Bekasi"}*? Mohon rincian biayanya. Terima kasih!`;
      break;

    case "calculator":
      text = `Halo Seni Api Listrik Bekasi (CV. Power Global),\n\nSaya telah menghitung estimasi biaya di website:\n• Pekerjaan: *${payload.categoryName}*\n• Ukuran/Kuantitas: *${payload.dimensionText}*\n• Pilihan Material: *${payload.gradeName}*\n• Estimasi Biaya: *${payload.priceText}*\n• Rencana Lokasi: *${payload.location || "Bekasi"}*\n\nMohon info lebih lanjut dan jadwal survei lokasi. Terima kasih!`;
      break;

    case "contact_form":
      text = `Halo Seni Api Listrik Bekasi,\n\nSaya ingin meminta penawaran pekerjaan:\n• Nama: ${payload.name || "-"}\n• Nomor Kontak: ${payload.phone || "-"}\n• Lokasi Pekerjaan: ${payload.location || "-"}\n• Jenis Pekerjaan: ${payload.service || "-"}\n• Catatan/Ukuran: ${payload.message || "-"}\n\nMohon dihubungi kembali. Terima kasih!`;
      break;

    case "general":
    default:
      text = `Halo Seni Api Listrik Bekasi (CV. Power Global),\n\nSaya ingin konsultasi pekerjaan fabrikasi, las, atau instalasi listrik di area Bekasi.\n• Rencana pekerjaan: ...\n• Lokasi: ...\n\nMohon dibantu info estimasi dan survei lokasinya. Terima kasih!`;
      break;
  }

  return `${base}?text=${encodeURIComponent(text)}`;
}

// Global exposure
if (typeof window !== "undefined") {
  window.SITE_CONFIG = SITE_CONFIG;
  window.getWhatsAppUrl = getWhatsAppUrl;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { SITE_CONFIG, getWhatsAppUrl };
}
