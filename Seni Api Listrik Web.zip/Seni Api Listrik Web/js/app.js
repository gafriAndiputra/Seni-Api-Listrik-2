/**
 * Main Application Logic for Seni Api Listrik Bekasi (CV. Power Global)
 * Handles:
 * - Dynamic portfolio rendering & category filtering
 * - Interactive lightbox with zoom, keyboard navigation & WA action
 * - Real-time price estimator calculator with custom WhatsApp output
 * - Schema-compliant FAQ accordion
 * - Direct contact form to WhatsApp converter
 * - Responsive mobile drawer & accessible navigation
 * - Sticky header & scroll observer
 */

document.addEventListener("DOMContentLoaded", () => {
  initHeaderAndNav();
  initPortfolio();
  initCalculator();
  initFaqAccordion();
  initContactForm();
  initCurrentYear();
  initSmoothScroll();
});

/* ==========================================================================
   1. Header, Navigation & Mobile Drawer
   ========================================================================== */
function initHeaderAndNav() {
  const header = document.getElementById("site-header");
  const menuToggle = document.getElementById("mobile-menu-toggle");
  const mobileDrawer = document.getElementById("mobile-drawer");
  const drawerOverlay = document.getElementById("drawer-overlay");
  const drawerCloseBtn = document.getElementById("drawer-close-btn");
  const navLinks = document.querySelectorAll(".nav-link, .drawer-link");

  // Scroll effect on header
  window.addEventListener("scroll", () => {
    if (window.scrollY > 40) {
      header.classList.add("header-scrolled");
    } else {
      header.classList.remove("header-scrolled");
    }
  }, { passive: true });

  // Toggle drawer
  function openDrawer() {
    mobileDrawer.classList.add("is-open");
    drawerOverlay.classList.add("is-visible");
    document.body.style.overflow = "hidden";
    menuToggle.setAttribute("aria-expanded", "true");
  }

  function closeDrawer() {
    mobileDrawer.classList.remove("is-open");
    drawerOverlay.classList.remove("is-visible");
    document.body.style.overflow = "";
    menuToggle.setAttribute("aria-expanded", "false");
  }

  if (menuToggle) {
    menuToggle.addEventListener("click", () => {
      const isOpen = mobileDrawer.classList.contains("is-open");
      isOpen ? closeDrawer() : openDrawer();
    });
  }

  if (drawerCloseBtn) {
    drawerCloseBtn.addEventListener("click", closeDrawer);
  }

  if (drawerOverlay) {
    drawerOverlay.addEventListener("click", closeDrawer);
  }

  // Close drawer when clicking any link
  navLinks.forEach(link => {
    link.addEventListener("click", () => {
      closeDrawer();
    });
  });

  // Esc key closes drawer & modal
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeDrawer();
      closeLightbox();
    }
  });

  // Scroll Spy for nav links
  const sections = document.querySelectorAll("section[id]");
  const observerOptions = {
    root: null,
    rootMargin: "-20% 0px -70% 0px",
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute("id");
        document.querySelectorAll(".nav-link").forEach(link => {
          link.classList.toggle("is-active", link.getAttribute("href") === `#${id}`);
        });
      }
    });
  }, observerOptions);

  sections.forEach(sec => observer.observe(sec));
}

/* ==========================================================================
   2. Portfolio Gallery & Lightbox
   ========================================================================== */
let activePortfolioFilter = "all";
let currentLightboxIndex = 0;
let currentFilteredList = [];

function initPortfolio() {
  const container = document.getElementById("portfolio-grid");
  const filterButtons = document.querySelectorAll(".filter-btn");

  if (!container || !window.SITE_CONFIG) return;

  currentFilteredList = [...window.SITE_CONFIG.portfolioItems];
  renderPortfolioItems(currentFilteredList);

  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("is-active"));
      btn.classList.add("is-active");

      const filter = btn.getAttribute("data-filter");
      activePortfolioFilter = filter;

      if (filter === "all") {
        currentFilteredList = [...window.SITE_CONFIG.portfolioItems];
      } else {
        currentFilteredList = window.SITE_CONFIG.portfolioItems.filter(item => item.category === filter);
      }

      renderPortfolioItems(currentFilteredList);
    });
  });

  initLightboxControls();
}

function renderPortfolioItems(items) {
  const container = document.getElementById("portfolio-grid");
  if (!container) return;

  if (items.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>Tidak ada portofolio untuk kategori ini.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = items.map((item, index) => {
    const waUrl = window.getWhatsAppUrl ? window.getWhatsAppUrl("portfolio", {
      title: item.title,
      tag: item.tag,
      location: item.location
    }) : `https://wa.me/6281398181885`;

    return `
      <article class="portfolio-card" data-index="${index}" data-category="${item.category}">
        <div class="portfolio-thumb-wrap" onclick="openLightbox(${index})">
          <img src="${item.image}" 
               alt="${escapeHtml(item.title)} - Seni Api Listrik Bekasi" 
               class="portfolio-img" 
               loading="lazy" 
               width="600" 
               height="450">
          <div class="portfolio-overlay">
            <span class="btn-zoom" aria-label="Perbesar foto">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                <line x1="11" y1="8" x2="11" y2="14"></line>
                <line x1="8" y1="11" x2="14" y2="11"></line>
              </svg>
              <span>Lihat Detail</span>
            </span>
          </div>
          <span class="portfolio-badge">${escapeHtml(item.tag)}</span>
        </div>
        <div class="portfolio-content">
          <div class="portfolio-meta">
            <span class="portfolio-loc">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
              </svg>
              ${escapeHtml(item.location)}
            </span>
          </div>
          <h3 class="portfolio-title">${escapeHtml(item.title)}</h3>
          <p class="portfolio-desc">${escapeHtml(item.desc)}</p>
          <div class="portfolio-actions">
            <button type="button" class="btn btn-sm btn-ghost" onclick="openLightbox(${index})">
              Perbesar
            </button>
            <a href="${waUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-wa-card" aria-label="Tanya model ${escapeHtml(item.title)} di WhatsApp">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
              </svg>
              <span>Tanya Model Ini</span>
            </a>
          </div>
        </div>
      </article>
    `;
  }).join("");
}

function openLightbox(index) {
  if (!currentFilteredList || currentFilteredList.length === 0) return;
  currentLightboxIndex = index;

  const modal = document.getElementById("lightbox-modal");
  const item = currentFilteredList[index];

  if (!modal || !item) return;

  updateLightboxContent(item);
  modal.classList.add("is-active");
  document.body.style.overflow = "hidden";
}

function closeLightbox() {
  const modal = document.getElementById("lightbox-modal");
  if (!modal) return;
  modal.classList.remove("is-active");
  document.body.style.overflow = "";
}

function updateLightboxContent(item) {
  const img = document.getElementById("lightbox-img");
  const title = document.getElementById("lightbox-title");
  const loc = document.getElementById("lightbox-location");
  const desc = document.getElementById("lightbox-desc");
  const tag = document.getElementById("lightbox-tag");
  const waBtn = document.getElementById("lightbox-wa-btn");
  const counter = document.getElementById("lightbox-counter");

  if (img) img.src = item.image;
  if (img) img.alt = item.title;
  if (title) title.textContent = item.title;
  if (loc) loc.textContent = item.location;
  if (desc) desc.textContent = item.desc;
  if (tag) tag.textContent = item.tag;
  if (counter) counter.textContent = `${currentLightboxIndex + 1} / ${currentFilteredList.length}`;

  if (waBtn) {
    const waUrl = window.getWhatsAppUrl ? window.getWhatsAppUrl("portfolio", {
      title: item.title,
      tag: item.tag,
      location: item.location
    }) : `https://wa.me/6281398181885`;
    waBtn.href = waUrl;
  }
}

function initLightboxControls() {
  const modal = document.getElementById("lightbox-modal");
  const closeBtn = document.getElementById("lightbox-close");
  const prevBtn = document.getElementById("lightbox-prev");
  const nextBtn = document.getElementById("lightbox-next");

  if (closeBtn) closeBtn.addEventListener("click", closeLightbox);

  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal || e.target.classList.contains("lightbox-backdrop")) {
        closeLightbox();
      }
    });
  }

  function showNext() {
    if (!currentFilteredList || currentFilteredList.length <= 1) return;
    currentLightboxIndex = (currentLightboxIndex + 1) % currentFilteredList.length;
    updateLightboxContent(currentFilteredList[currentLightboxIndex]);
  }

  function showPrev() {
    if (!currentFilteredList || currentFilteredList.length <= 1) return;
    currentLightboxIndex = (currentLightboxIndex - 1 + currentFilteredList.length) % currentFilteredList.length;
    updateLightboxContent(currentFilteredList[currentLightboxIndex]);
  }

  if (nextBtn) nextBtn.addEventListener("click", showNext);
  if (prevBtn) prevBtn.addEventListener("click", showPrev);

  window.addEventListener("keydown", (e) => {
    if (!modal || !modal.classList.contains("is-active")) return;
    if (e.key === "ArrowRight") showNext();
    if (e.key === "ArrowLeft") showPrev();
  });
}

// Attach globally for inline onclick
window.openLightbox = openLightbox;
window.closeLightbox = closeLightbox;

/* ==========================================================================
   3. Interactive Pricing Estimator (Kalkulator Estimasi Biaya)
   ========================================================================== */
function initCalculator() {
  const config = window.SITE_CONFIG ? window.SITE_CONFIG.pricingConfig : null;
  if (!config) return;

  const selectCategory = document.getElementById("calc-category");
  const inputLength = document.getElementById("calc-length");
  const inputWidth = document.getElementById("calc-width");
  const inputCount = document.getElementById("calc-count");
  const inputLocation = document.getElementById("calc-location");
  const areaGroup = document.getElementById("calc-dim-group");
  const countGroup = document.getElementById("calc-count-group");

  const gradeInputs = document.querySelectorAll('input[name="calc-grade"]');

  const resultArea = document.getElementById("calc-res-area");
  const resultRange = document.getElementById("calc-res-range");
  const resultSpecs = document.getElementById("calc-res-specs");
  const btnSendWa = document.getElementById("calc-btn-wa");

  // Populate Categories
  if (selectCategory) {
    selectCategory.innerHTML = config.categories.map(cat => `
      <option value="${cat.id}">${escapeHtml(cat.name)}</option>
    `).join("");
  }

  function getCurrentCategory() {
    const val = selectCategory ? selectCategory.value : config.categories[0].id;
    return config.categories.find(c => c.id === val) || config.categories[0];
  }

  function getCurrentGrade() {
    let selectedGradeId = "standar";
    gradeInputs.forEach(radio => {
      if (radio.checked) selectedGradeId = radio.value;
    });
    return config.materialGrades.find(g => g.id === selectedGradeId) || config.materialGrades[0];
  }

  function handleCategoryChange() {
    const cat = getCurrentCategory();

    if (cat.unitType === "area") {
      if (areaGroup) areaGroup.style.display = "grid";
      if (countGroup) countGroup.style.display = "none";
      if (inputLength && cat.defaultLength) inputLength.value = cat.defaultLength;
      if (inputWidth && cat.defaultWidth) inputWidth.value = cat.defaultWidth;
      const widthLabel = document.getElementById("calc-width-label");
      if (widthLabel) widthLabel.textContent = "Lebar (Meter)";
    } else if (cat.unitType === "length") {
      if (areaGroup) areaGroup.style.display = "grid";
      if (countGroup) countGroup.style.display = "none";
      if (inputLength && cat.defaultLength) inputLength.value = cat.defaultLength;
      if (inputWidth) {
        inputWidth.value = 1;
        inputWidth.parentElement.style.display = "none";
      }
    } else { // count
      if (areaGroup) areaGroup.style.display = "none";
      if (countGroup) countGroup.style.display = "block";
      if (inputCount && cat.defaultCount) inputCount.value = cat.defaultCount;
      const countLabel = document.getElementById("calc-count-label");
      if (countLabel) countLabel.textContent = `Jumlah ${cat.unitLabel}`;
    }

    // Reset width display if not length
    if (cat.unitType !== "length" && inputWidth && inputWidth.parentElement) {
      inputWidth.parentElement.style.display = "block";
    }

    calculateTotal();
  }

  function calculateTotal() {
    const cat = getCurrentCategory();
    const grade = getCurrentGrade();
    const loc = (inputLocation && inputLocation.value.trim()) ? inputLocation.value.trim() : "Bekasi";

    let quantity = 0;
    let dimensionText = "";

    if (cat.unitType === "area") {
      const len = parseFloat(inputLength.value) || 0;
      const wid = parseFloat(inputWidth.value) || 0;
      quantity = Math.max(0.1, len * wid);
      dimensionText = `${len}m x ${wid}m (${quantity.toFixed(1)} m²)`;
    } else if (cat.unitType === "length") {
      const len = parseFloat(inputLength.value) || 0;
      quantity = Math.max(0.5, len);
      dimensionText = `${quantity.toFixed(1)} meter lari`;
    } else {
      const cnt = parseInt(inputCount.value, 10) || 1;
      quantity = Math.max(1, cnt);
      dimensionText = `${quantity} ${cat.unitLabel}`;
    }

    const estimatedBase = quantity * cat.basePrice * grade.multiplier;
    const lowerEst = Math.round(estimatedBase * 0.95);
    const upperEst = Math.round(estimatedBase * 1.08);

    const formatIdr = (val) => new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0
    }).format(val);

    const priceText = `${formatIdr(lowerEst)} – ${formatIdr(upperEst)}`;

    if (resultArea) resultArea.textContent = dimensionText;
    if (resultRange) resultRange.textContent = priceText;
    if (resultSpecs) resultSpecs.textContent = `${cat.desc} Grade: ${grade.name}.`;

    if (btnSendWa) {
      const waUrl = window.getWhatsAppUrl ? window.getWhatsAppUrl("calculator", {
        categoryName: cat.name,
        dimensionText: dimensionText,
        gradeName: grade.name,
        priceText: priceText,
        location: loc
      }) : `https://wa.me/6281398181885`;

      btnSendWa.href = waUrl;
    }
  }

  if (selectCategory) selectCategory.addEventListener("change", handleCategoryChange);
  if (inputLength) inputLength.addEventListener("input", calculateTotal);
  if (inputWidth) inputWidth.addEventListener("input", calculateTotal);
  if (inputCount) inputCount.addEventListener("input", calculateTotal);
  if (inputLocation) inputLocation.addEventListener("input", calculateTotal);

  gradeInputs.forEach(radio => {
    radio.addEventListener("change", calculateTotal);
  });

  // Initial trigger
  handleCategoryChange();
}

/* ==========================================================================
   4. FAQ Accordion
   ========================================================================== */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll(".faq-item");

  faqItems.forEach(item => {
    const questionBtn = item.querySelector(".faq-question");
    if (!questionBtn) return;

    questionBtn.addEventListener("click", () => {
      const isOpen = item.classList.contains("is-open");

      // Optional: close other items for clean accordion UX
      faqItems.forEach(other => {
        if (other !== item) {
          other.classList.remove("is-open");
          const otherBtn = other.querySelector(".faq-question");
          if (otherBtn) otherBtn.setAttribute("aria-expanded", "false");
        }
      });

      if (isOpen) {
        item.classList.remove("is-open");
        questionBtn.setAttribute("aria-expanded", "false");
      } else {
        item.classList.add("is-open");
        questionBtn.setAttribute("aria-expanded", "true");
      }
    });
  });
}

/* ==========================================================================
   5. Direct Contact Form to WhatsApp
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById("quick-contact-form");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("form-name")?.value.trim() || "";
    const phone = document.getElementById("form-phone")?.value.trim() || "";
    const loc = document.getElementById("form-loc")?.value.trim() || "";
    const service = document.getElementById("form-service")?.value || "";
    const message = document.getElementById("form-message")?.value.trim() || "";

    const waUrl = window.getWhatsAppUrl ? window.getWhatsAppUrl("contact_form", {
      name,
      phone,
      location: loc,
      service,
      message
    }) : `https://wa.me/6281398181885`;

    window.open(waUrl, "_blank", "noopener,noreferrer");
  });
}

/* ==========================================================================
   6. Footer Year & Smooth Scroll Utilities
   ========================================================================== */
function initCurrentYear() {
  const yearEls = document.querySelectorAll("#current-year");
  const year = new Date().getFullYear();
  yearEls.forEach(el => {
    el.textContent = year;
  });
}

function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function(e) {
      const href = this.getAttribute("href");
      if (href === "#" || href === "") return;

      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
      }
    });
  });
}

/**
 * Basic HTML escaping helper
 */
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
