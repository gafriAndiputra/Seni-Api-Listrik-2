# Seni Api Listrik Bekasi (CV. Power Global) — Website Resmi & Local SEO

Website resmi berkonsep **Modern Industrial Workshop** untuk **Seni Api Listrik Bekasi** (CV. Power Global), dirancang khusus untuk mendominasi pencarian lokal Google di Bekasi dan mengonversi calon pelanggan lokal untuk jasa fabrikasi besi/baja, bengkel las listrik, dan instalasi sistem kelistrikan.

---

## 🌟 Fitur Utama & Keunggulan

1. **Aset Visual & Estetika Industrial Modern**:
   - Tema *Dark Metal Workshop* (`#090a0d`, `#151921`) dengan aksen pendaran las oranye (*Molten Welding Spark* `#ff6a00`, `#ff8533`) dan aksen plasma cyan.
   - Menggunakan logo resmi resolusi tinggi dan favicon resmi Seni Api Listrik (SAL).
   - Tipografi industri berkarakter kokoh (*Rajdhani* untuk heading dan *Plus Jakarta Sans* untuk keterbacaan body text).

2. **Galeri Portofolio Nyata (24 Proyek Lapangan)**:
   - Terintegrasi langsung dengan foto-foto hasil pekerjaan asli workshop di Tambun Selatan & sekitarnya.
   - Filter kategori interaktif: *Semua*, *Pagar & Gerbang*, *Kanopi & Rangka*, *Rolling Door & Lift*, *Neon Box Usaha*, *Instalasi Listrik & Panel*, serta *Teralis & Fabrikasi Khusus*.
   - Modal Lightbox interaktif dengan fitur perbesaran gambar, navigasi keyboard (panah kiri/kanan, Esc), serta tombol langsung *"Pesan Model Ini via WhatsApp"*.

3. **Kalkulator Estimasi Biaya Fabrikasi & Las Interaktif**:
   - Menghitung simulasi biaya secara real-time berdasarkan dimensi (m² atau meter lari) atau jumlah unit/titik.
   - Opsi grade material: *Standar SNI*, *Premium Heavy Duty*, dan *Industrial / Stainless 304*.
   - Tombol konversi satu ketukan *"Kirim Rincian ke WhatsApp"* yang otomatis merangkum data kalkulasi menjadi pesan chat terstruktur.

4. **Optimasi Google Local SEO (Bekasi & Sekitarnya)**:
   - **JSON-LD Schema Markup** lengkap untuk `HomeAndConstructionBusiness`, `LocalBusiness`, dan `FAQPage` rich snippets.
   - Meta tag Geo resmi (`ID-JB`, koordinat lintang/bujur Tambun Selatan Bekasi).
   - Penargetan kata kunci lokal: *Tambun Selatan, Cikarang, Cibitung, Bekasi Timur, Bekasi Barat, Bekasi Selatan, Bekasi Utara, Mustika Jaya, Grand Wisata, Summarecon Bekasi*.

5. **Integrasi WhatsApp CTA di Seluruh Alur Konversi**:
   - Tombol floating WhatsApp di sudut kanan bawah dengan status indikator.
   - Tombol WhatsApp kontekstual di setiap kartu layanan dengan pesan otomatis tersuai.
   - Formulir kontak cepat yang langsung membuka WhatsApp dengan data nama, nomor, lokasi, dan kebutuhan pengerjaan.

6. **FAQ Interaktif**:
   - Accordion interaktif berisi 6 tanya-jawab krusial mengenai survei lokasi, material SNI, durasi pengerjaan, dan garansi.

---

## 🚀 Cara Menjalankan Server Lokal

Website ini dibangun menggunakan arsitektur statis murni tanpa dependensi runtime eksternal. Dapat dijalankan langsung menggunakan server bawaan Ruby WEBrick:

```bash
ruby server.rb 8088
```

Kemudian buka di peramban: [http://localhost:8088](http://localhost:8088)

Atau buka langsung berkas `index.html` via browser.

---

## 📁 Struktur Berkas

```
Seni Api Listrik Web/
├── index.html                  # Landing page semantik lengkap dengan Local SEO & JSON-LD
├── server.rb                   # Server lokal WEBrick ringan (port 8088)
├── README.md                   # Dokumentasi proyek
├── css/
│   └── style.css               # Desain sistem modular industrial workshop & animasi
├── js/
│   ├── config.js               # Konfigurasi data bisnis, layanan, portofolio & WhatsApp generator
│   └── app.js                  # Logika interaktif: filter, lightbox, kalkulator, FAQ, drawer
└── assets/
    ├── images/
    │   ├── logo.png            # Logo resmi Seni Api Listrik
    │   └── favicon.png         # Favicon resolusi tinggi
    └── portfolio/              # 24 aset foto pekerjaan asli terorganisir
```

---

&copy; 2026 Seni Api Listrik Bekasi — CV. Power Global.
